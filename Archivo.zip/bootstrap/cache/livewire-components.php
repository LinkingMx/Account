<?php return array (
  'show-balance' => 'App\\Http\\Livewire\\ShowBalance',
);